Live site : https://labo1-olivierlaliberte-09152022.glitch.me

Live site code : https://glitch.com/edit/#!/labo1-olivierlaliberte-09152022